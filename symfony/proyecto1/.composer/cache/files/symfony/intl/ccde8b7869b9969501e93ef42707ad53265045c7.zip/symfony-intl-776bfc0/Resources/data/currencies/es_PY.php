<?php

return [
    'Names' => [
        'PYG' => [
            0 => 'Gs.',
            1 => 'guaraní paraguayo',
        ],
    ],
];
