<?php

return [
    'Names' => [
        'XCD' => [
            0 => '$',
            1 => 'East Caribbean Dollar',
        ],
    ],
];
