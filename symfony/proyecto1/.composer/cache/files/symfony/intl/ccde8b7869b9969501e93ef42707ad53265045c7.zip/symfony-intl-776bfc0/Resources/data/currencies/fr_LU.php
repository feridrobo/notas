<?php

return [
    'Names' => [
        'FRF' => [
            0 => 'FRF',
            1 => 'franc français',
        ],
        'LUF' => [
            0 => 'F',
            1 => 'franc luxembourgeois',
        ],
    ],
];
