<?php

return [
    'Names' => [
        'AUD' => [
            0 => '$',
            1 => 'Australian Dollar',
        ],
    ],
];
