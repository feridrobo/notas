<?php

return [
    'Names' => [
        'AWG' => [
            0 => 'Afl.',
            1 => 'Arubaanse gulden',
        ],
    ],
];
