<?php

return [
    'Names' => [
        'VUV' => [
            0 => 'VT',
            1 => 'vatu vanuatuan',
        ],
    ],
];
