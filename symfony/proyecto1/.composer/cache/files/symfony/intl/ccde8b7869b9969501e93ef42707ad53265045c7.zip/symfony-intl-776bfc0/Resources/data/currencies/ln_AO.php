<?php

return [
    'Names' => [
        'AOA' => [
            0 => 'Kz',
            1 => 'Kwanza ya Angóla',
        ],
    ],
];
