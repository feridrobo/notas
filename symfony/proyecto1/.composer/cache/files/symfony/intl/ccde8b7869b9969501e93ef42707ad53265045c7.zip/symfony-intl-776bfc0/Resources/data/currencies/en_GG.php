<?php

return [
    'Names' => [
        'GBP' => [
            0 => '£',
            1 => 'UK Pound',
        ],
    ],
];
