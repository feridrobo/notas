<?php

return [
    'Names' => [
        'IDR' => [
            0 => 'Rp',
            1 => 'Rupiah Indonesia',
        ],
    ],
];
